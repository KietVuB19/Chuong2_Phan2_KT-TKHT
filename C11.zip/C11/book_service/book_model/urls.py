from book_model import views
from django.urls import path

urlpatterns = [
    path('', views.get_book_data,name='get_book_data'),
]
