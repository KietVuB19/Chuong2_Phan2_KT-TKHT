from django.urls import path
from user_model import views
urlpatterns = [
    path('',views.registration_req, name='registration_req'),
]
