from django.contrib import admin

from product_model.models import product_details

# Register your models here.
admin.site.register(product_details)
