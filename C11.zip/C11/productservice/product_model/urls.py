from product_model import views
from django.urls import path

urlpatterns = [
    path('', views.get_product_data,name='get_product_data'),
]
