from django.apps import AppConfig


class ShipmentUpdateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shipment_update'
