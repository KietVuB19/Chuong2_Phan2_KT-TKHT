from django.urls import path
from shipment_update import views

urlpatterns = [
]