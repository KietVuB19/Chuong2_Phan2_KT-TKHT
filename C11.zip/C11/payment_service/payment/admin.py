from django.contrib import admin
from payment.models import payment_status
# Register your models here.
admin.site.register(payment_status)