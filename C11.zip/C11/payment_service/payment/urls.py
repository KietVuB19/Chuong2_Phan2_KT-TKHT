from django.urls import path
from payment import views

urlpatterns = [
    path('get_payment/',views.get_payment),
    path('user_transaction_info/', views.user_transaction_info),
]