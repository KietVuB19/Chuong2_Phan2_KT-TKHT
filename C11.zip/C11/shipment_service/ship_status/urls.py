from django.urls import path
from . import views

urlpatterns = [
    path('',views.shipment_status,name='get_product_data'),
]
